﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sol_PuntoVenta.Entidades
{
    public class E_Punto_Venta
    {
        public int Codigo_pv { get; set; }
        public string Descripcion_pv { get; set; }
    }
}
