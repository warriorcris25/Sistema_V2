﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sol_PuntoVenta.Entidades
{
    public class E_Familias
    {
        public int Codigo_fa { get; set; }
        public string Descripcion_fa { get; set; }
    }
}
